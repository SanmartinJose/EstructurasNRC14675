var searchData=
[
  ['pausa_0',['pausa',['../main_8cpp.html#ad3befffba77b3954d6bbea4d22afc517',1,'main.cpp']]]
];
