var indexSectionsWithContent =
{
  0: "acdefgilmnoprstv",
  1: "fnt",
  2: "fmnt",
  3: "acdefglmnoprstv",
  4: "acefinst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

