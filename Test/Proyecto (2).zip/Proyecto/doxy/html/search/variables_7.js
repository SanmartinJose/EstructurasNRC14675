var searchData=
[
  ['tabla_0',['tabla',['../main_8cpp.html#a21c7e71da037f160cc78e5fe54740ea9',1,'main.cpp']]]
];
