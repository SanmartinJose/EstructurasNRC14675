var searchData=
[
  ['fecha_0',['fecha',['../class_fecha.html#ac4157fc747f60e0f1d3c1ddb2182fd09',1,'Fecha::Fecha(int d, int m, int a)'],['../class_fecha.html#a7b55abb83291d5c960e9f8104a6eea6e',1,'Fecha::Fecha()']]]
];
