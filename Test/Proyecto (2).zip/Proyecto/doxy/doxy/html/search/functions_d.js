var searchData=
[
  ['setanterior_0',['setAnterior',['../class_nodo.html#a73f85bd0a63f8fc4c73af4abe61a1577',1,'Nodo']]],
  ['setdato_1',['setDato',['../class_nodo.html#acf46078c62f4f551694f02897600a611',1,'Nodo']]],
  ['setsiguiente_2',['setsiguiente',['../class_nodo.html#ae3ab15a287f33983923c8f0594e7a1a7',1,'Nodo::setSiguiente()'],['../class_nodo_lista.html#a71240b16ab16bb3dd75e614633e79cef',1,'NodoLista::setSiguiente()']]]
];
