var class_nodo_lista =
[
    [ "getDato", "class_nodo_lista.html#a243a89c44c62f02da2a519df5af12698", null ],
    [ "getSiguiente", "class_nodo_lista.html#a164b7892edbe562c13317e1b9305fbeb", null ],
    [ "Nodo", "class_nodo_lista.html#a0198468be60e8e4c421a55b6cbfd301d", null ],
    [ "setSiguiente", "class_nodo_lista.html#a71240b16ab16bb3dd75e614633e79cef", null ]
];