var class_nodo =
[
    [ "Nodo", "class_nodo.html#acdd363e02aa434714ea8617b9dc4d44b", null ],
    [ "getAnterior", "class_nodo.html#afff41840aa78a6cbb1db3c79f8406e0a", null ],
    [ "getDato", "class_nodo.html#acdef37bb656169b5bfe9808f176c8308", null ],
    [ "getSiguiente", "class_nodo.html#a9be453ba1773864e0f49eaac024e0e0a", null ],
    [ "setAnterior", "class_nodo.html#a73f85bd0a63f8fc4c73af4abe61a1577", null ],
    [ "setDato", "class_nodo.html#acf46078c62f4f551694f02897600a611", null ],
    [ "setSiguiente", "class_nodo.html#ae3ab15a287f33983923c8f0594e7a1a7", null ]
];