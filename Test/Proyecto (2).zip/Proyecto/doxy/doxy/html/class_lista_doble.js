var class_lista_doble =
[
    [ "ListaDoble", "class_lista_doble.html#ac9a17849733bd09928c988258a56842a", null ],
    [ "Buscar", "class_lista_doble.html#a56a5839e01762eef2ee2d6bd6515f70e", null ],
    [ "Eliminar", "class_lista_doble.html#a4e9edda3ae747c59c99a026502ecd82b", null ],
    [ "Insertar", "class_lista_doble.html#a3a42bf42fecbffd1079e501fdebd5f79", null ],
    [ "Mostrar", "class_lista_doble.html#a386e862be6c6681830c8791ebcaeb264", null ],
    [ "Attribute1", "class_lista_doble.html#a9531b765943e67de60d6aa594e89b821", null ],
    [ "Attribute2", "class_lista_doble.html#a3cd1115c50139c5e689ca54415e0bc6e", null ]
];