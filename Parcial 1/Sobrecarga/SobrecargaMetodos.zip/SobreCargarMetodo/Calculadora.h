template <typename T>
class Calculadora {
public:
    T sumar(T a, T b);
    T sumar(T a, T b, T c);
};

#include "Calculadora.cpp"