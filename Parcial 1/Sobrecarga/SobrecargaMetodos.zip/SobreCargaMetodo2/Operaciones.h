template <typename T>

class Operaciones {
public:
    T multiplicar(T a, T b);
};

#include "Operaciones.cpp"