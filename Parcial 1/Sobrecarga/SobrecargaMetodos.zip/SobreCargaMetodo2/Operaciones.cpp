template <typename T>
T Operaciones<T>::multiplicar(T a, T b) {
    return a * b;
}